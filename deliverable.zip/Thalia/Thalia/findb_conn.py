# seperate file from the __init__.py to avoid circular imports
# when accessing findb from other modules
findb = None
