MAX_PORTFOLIOS = 5
OFFICIAL_COLOURS = [
    "#f26a4b",
    "#01434a",
    "#01191c",
    "#f23d3d",
    "#d0d42b",
]
NO_TABS = 7
