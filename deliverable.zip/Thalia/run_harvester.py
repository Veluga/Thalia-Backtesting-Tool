from DataHarvester.dhav_core.run_updates import run_me
import time

while True:
    run_me()
    time.sleep(1200)