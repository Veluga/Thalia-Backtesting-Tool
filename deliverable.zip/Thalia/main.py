from Thalia import create_app

server = create_app()
