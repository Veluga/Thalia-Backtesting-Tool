---
name: User story
about: Agile style user story
title: ''
labels: ''
assignees: ''

---

As <user type>, I want <feature>, so <benefit>.

**Value**
<provide bullet point list of benefits in implementing feature>

**Acceptance criteria**
<list of requirements in the form of questions that
that need to be answered before ticket is done
e.g. Does website support https?, Have chart acronyms
been user tested?>
